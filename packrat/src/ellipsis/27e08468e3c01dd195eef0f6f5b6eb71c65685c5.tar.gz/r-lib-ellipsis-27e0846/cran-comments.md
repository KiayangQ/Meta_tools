## Test environments
* local OS X install: R-release
* travis-ci: 3.2, 3.3, 3.4, 3.5, R-release, R-devel
* win-builder: R-devel

## revdepcheck results

We checked 3 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages
